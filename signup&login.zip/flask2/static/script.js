document.addEventListener("DOMContentLoaded", () => {
  // Signup validation
  const signupForm = document.getElementById("signupForm");
  if (signupForm) {
    signupForm.addEventListener("submit", (e) => {
      const password = signupForm.querySelector("input[name='password']").value;
      const confirmPassword = signupForm.querySelector("input[name='confirm_password']").value;
      const phone = signupForm.querySelector("input[name='phone']").value;

      // Password match check
      if (password !== confirmPassword) {
        e.preventDefault();
        showAlert("❌ Passwords do not match!", "error");
        return;
      }

      // Phone number validation
      if (!/^\d{10}$/.test(phone)) {
        e.preventDefault();
        showAlert("📱 Phone number must be 10 digits!", "error");
        return;
      }
    });
  }

  // Login validation
  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      const username = loginForm.querySelector("input[name='username']").value.trim();
      const password = loginForm.querySelector("input[name='password']").value;

      if (username === "" || password === "") {
        e.preventDefault();
        showAlert("⚠️ Please fill all fields!", "error");
      }
    });
  }
});

/**
 * Show custom colorful alerts
 */
function showAlert(message, type = "error") {
  let flashContainer = document.getElementById("flash-container");

  if (!flashContainer) {
    flashContainer = document.createElement("div");
    flashContainer.id = "flash-container";
    document.querySelector(".form-container").prepend(flashContainer);
  }

  const alertBox = document.createElement("div");
  alertBox.className = `flash ${type}`;
  alertBox.textContent = message;

  flashContainer.appendChild(alertBox);

  // Auto-remove after 3s
  setTimeout(() => {
    alertBox.style.opacity = "0";
    setTimeout(() => alertBox.remove(), 600);
  }, 3000);
}
