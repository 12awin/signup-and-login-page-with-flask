from flask import Flask, redirect, url_for, session, request, render_template, flash
import requests
from google.oauth2 import id_token
from google.auth.transport import requests as grequests
import json

app = Flask(__name__)
app.secret_key = "your_secret_key"

# Replace with your credentials from Google Cloud Console
GOOGLE_CLIENT_ID = "YOUR_GOOGLE_CLIENT_ID"
GOOGLE_CLIENT_SECRET = "YOUR_GOOGLE_CLIENT_SECRET"
GOOGLE_DISCOVERY_URL = "https://accounts.google.com/.well-known/openid-configuration"

# Dummy user DB
users = {}

def get_google_provider_cfg():
    return requests.get(GOOGLE_DISCOVERY_URL).json()

@app.route("/")
def home():
    if "username" in session:
        return f"Welcome {session['username']}! <a href='/logout'>Logout</a>"

    if "google_user" in session:
        user = session["google_user"]
        return f"""
        <h2>Welcome {user['name']} (Google)</h2>
        <p>Email: {user['email']}</p>
        <img src="{user['picture']}" width="100"><br>
        <a href='/logout'>Logout</a>
        """

    return redirect(url_for("login"))

@app.route("/signup", methods=["GET", "POST"])
def signup():
    return render_template("signup.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        if username in users and users[username]["password"] == password:
            session["username"] = username
            flash(f"🎉 Welcome {users[username]['name']}!", "success")
            return redirect(url_for("home"))
        else:
            flash("❌ Invalid username or password", "error")
            return redirect(url_for("login"))

    return render_template("login.html")

@app.route('/forgot-password', methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        email = request.form.get("email")
        # Later: Send reset link to email
        flash(f"📧 If an account with {email} exists, a reset link will be sent.", "info")
        return redirect(url_for("login"))

    return render_template("forgot_password.html")


# ----------- GOOGLE LOGIN ----------- #
@app.route("/google_login")
def google_login():
    google_cfg = get_google_provider_cfg()
    authorization_endpoint = google_cfg["authorization_endpoint"]

    request_uri = (
        f"{authorization_endpoint}?response_type=code"
        f"&client_id={GOOGLE_CLIENT_ID}"
        f"&redirect_uri={url_for('google_callback', _external=True)}"
        f"&scope=openid%20email%20profile"
    )
    return redirect(request_uri)

@app.route("/google_callback")
def google_callback():
    code = request.args.get("code")

    # Get token endpoint
    google_cfg = get_google_provider_cfg()
    token_endpoint = google_cfg["token_endpoint"]

    # Exchange code for tokens
    token_url, headers, body = (
        token_endpoint,
        {"Content-Type": "application/x-www-form-urlencoded"},
        {
            "code": code,
            "client_id": GOOGLE_CLIENT_ID,
            "client_secret": GOOGLE_CLIENT_SECRET,
            "redirect_uri": url_for("google_callback", _external=True),
            "grant_type": "authorization_code",
        },
    )

    token_response = requests.post(token_url, headers=headers, data=body)
    tokens = token_response.json()

    # Verify ID token
    idinfo = id_token.verify_oauth2_token(
        tokens["id_token"], grequests.Request(), GOOGLE_CLIENT_ID
    )

    # Save user info in session
    session["google_user"] = {
        "id": idinfo["sub"],
        "name": idinfo["name"],
        "email": idinfo["email"],
        "picture": idinfo["picture"],
    }

    flash(f"🎉 Welcome {idinfo['name']} (Google)!", "success")
    return redirect(url_for("home"))

@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out successfully!", "info")
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(debug=True)

